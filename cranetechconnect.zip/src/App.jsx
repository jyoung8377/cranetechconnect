import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#1A1D1E] text-white">
      <header className="flex items-center justify-between p-6 bg-black">
        <h1 className="text-xl font-bold text-[#ECC239]">Crane Tech Connect</h1>
        <nav className="space-x-4">
          <a href="#" className="hover:text-[#ECC239]">Home</a>
          <a href="#" className="hover:text-[#ECC239]">How It Works</a>
          <a href="#" className="hover:text-[#ECC239]">Login</a>
        </nav>
      </header>
      <main className="flex flex-col items-center justify-center text-center py-20 px-6">
        <h2 className="text-4xl font-bold mb-4">The First Technical Support Marketplace for Crane Mechanics</h2>
        <p className="mb-8 max-w-xl">Connect with experienced technicians. Get help fast. Pay only for the time you need.</p>
        <div className="space-x-4">
          <button className="bg-[#ECC239] text-black font-bold py-2 px-4 rounded hover:opacity-90">Request Help</button>
          <button className="border border-[#ECC239] text-[#ECC239] font-bold py-2 px-4 rounded hover:bg-[#ECC239] hover:text-black">Offer Support</button>
        </div>
      </main>
    </div>
  );
}
